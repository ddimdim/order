﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order
{
    internal class Order
    {
        private List<Product> product;
        public int Number;
        public DateTime OrderTime;

        public Order (List<Product> _product, int number, DateTime ordertime)
        {
            this.product = _product;
            this.Number = number;
            this.OrderTime = ordertime;
        }

        public void AddProduct (Product _product)
        {
            product.Add(_product);
        }
        public void Clear ()
        {
            
        }

        public decimal TotalPrice ()
        {
            
        }
    }
}
