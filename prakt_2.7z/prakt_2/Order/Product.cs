﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order
{
    abstract class Product
    {
        private decimal basePrice;
        public string Name;
        public string ImagePath;

        public Product (decimal _baseprice, string name, string imagepath)
        {
            this.basePrice = _baseprice;
            this.Name = name;
            this.ImagePath = imagepath;
        }

        abstract public decimal GetPrice()
        {
            return basePrice;
        }
    }
}
