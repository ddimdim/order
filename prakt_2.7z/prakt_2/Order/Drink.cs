﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order
{
    internal class Drink : Product
    {
        public int Volume;
        public bool IsBotted;

        public Drink (decimal baseprice, string name, string imagepath, int volume, bool isbotted) : base(baseprice, name, imagepath) {
            this.Volume = volume;
            this.IsBotted = isbotted;
        }
        public override decimal GetPrice ()
        {
            if (IsBotted)
            {
                return GetPrice() + 25;
            }
            else
            {
                return GetPrice();
            }
        }
    }
}
