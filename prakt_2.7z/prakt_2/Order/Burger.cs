﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Order
{
    internal class Burger : Product
    {
        private List<Option> options;

        public Burger (decimal _baseprice, string name, string imagepath, List<Option> _options) : base(_baseprice, name, imagepath)
        {
            this.options = _options;
        }

        public override decimal GetPrice ()
        {
            
        }
    }
}
